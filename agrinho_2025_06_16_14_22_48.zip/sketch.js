function setup() {
  createCanvas(800, 400);
}

let xJogador1 = 0;
let xJogador2 = 0;
let rdm = 40;

function draw() {
  ativaJogo();
  desenhaJogadores();
  verificaVencedor();
}

function ativaJogo() {
  if (focused == true) {
    background("#D2EBB5");
  } else {
    background("rgb(238,178,178)");
  }
}

function desenhaJogadores() {
  textSize(40);
  text("🏀", xJogador1, 100);
  
}

function verificaVencedor() {
  if (xJogador1 > 750) {

    text("O campo é o local onde muitos moram pois", 0, 200);
    text("podem possuir uma vida tranquila", 0, 230);
    noLoop();
    
  }
 
}

function keyPressed() {
  if (key == "d") {
    xJogador1 += random(rdm);
  }
  
}
